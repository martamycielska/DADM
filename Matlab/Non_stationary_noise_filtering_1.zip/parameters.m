clear all
close all

load('test.mat');
W=[7,7];
I_matlab=lmmse(In,W,MapaR);

figure(1); imshow(In,[]);
figure(2); imshow(I_matlab,[]);

