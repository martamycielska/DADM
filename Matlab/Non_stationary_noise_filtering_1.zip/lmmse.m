function image_filtered=lmmse(image,W,sigma)
    sigma=sigma.^2;
    M2=filter2(ones(W), image.^2) ./ (prod(W)); %moment II rzedu
    M4=filter2(ones(W),image.^4)./prod(W); %moment IV rzedu
    K=1+(4.*sigma.^2-4.*sigma.*M2)./(M4-M2.^2); %parametr K
    K=max(K,0);
    image_filtered=sqrt(M2-2.*sigma+K.*(image.^2-M2));
    image_filtered=abs(image_filtered); %obraz odszumiony
end

