function [output] = UNLM(input, Rsim, sigma, Rsearch, M, N, output, gaussian_kernel)
    for i = 1:M
        for j = 1:N
            i_1 = i + Rsim;
            j_1 = j + Rsim;
            Np = input(i:i_1+Rsim, j:j_1+Rsim);
            wmax = 0;
            Z = 0;
            Yq = 0;

            k1 = max(i_1 - Rsearch, Rsim + 1);
            k2 = min(i_1 + Rsearch, M + Rsim);
            l1 = max(j_1 - Rsearch, Rsim + 1);
            l2 = min(j_1 + Rsearch, N + Rsim);

            for k = k1:1:k2
                for l = l1:1:l2
                    if k == i_1 && l == j_1
                        w = wmax; 
                    else
                        Nq = input(k-Rsim:k+Rsim, l-Rsim:l+Rsim);              

                        d = sum(sum(gaussian_kernel.*(Np-Nq).*(Np-Nq)));

                        h = 1.22*sigma(i,j);
                        w = exp(-d/(h*h));                

                        if w > wmax                
                            wmax = w;                   
                        end
                    end
                    Z = Z + w;
                    Yq = Yq + w*(input(k,l).^2); 
                end
            end
            Z = Z + wmax;
            Yq = Yq + wmax*(input(i_1,j_1).^2);
            if Z > 0
                output(i,j) = sqrt(abs(Yq/Z - 2*sigma(i,j)^2));
            else
                output(i,j) = input(i,j);
            end 
        end
    end
end

