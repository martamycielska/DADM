clear all
close all
clc
orig1 = csvread('origin1.csv');
noise1 = csvread('szum1.csv');
input1 = orig1;
sigma = noise1;
figure, imshow(input1, [])

Rsim = 2;
Rsearch = 5;
[M, N]=size(input1);
output = zeros(M,N);
input = zeros(M+2*Rsim, N+2*Rsim);
input(Rsim+1:M+Rsim, Rsim+1:N+Rsim) = input1(1:M,1:N);

%1 Generate Gaussian Kernel
gaussian_kernel = gauss_kernel(Rsim);
%2 Count UNLM
output = UNLM(input, Rsim, sigma, Rsearch, M, N, output, gaussian_kernel);
figure, imshow(output, []);
figure, imshow(input1 - output, []);