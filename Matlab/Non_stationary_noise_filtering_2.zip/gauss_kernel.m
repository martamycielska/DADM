function [gaussian_kernel] = gauss_kernel(Rsim)
    kernel_sum = 0;
    g_sigma = 1;    
    for i = -Rsim:1:Rsim
        for j = -Rsim:1:Rsim
            e = exp(0.5*(i*i + j*j)/(2*g_sigma*g_sigma));
            gaussian_kernel(i+Rsim+1, j+Rsim+1) = e/(2*pi*g_sigma*g_sigma);
            kernel_sum = kernel_sum + gaussian_kernel(i+Rsim+1, j+Rsim+1);
        end
    end
    for i = -Rsim:1:Rsim
        for j = -Rsim:1:Rsim
            gaussian_kernel(i+Rsim+1, j+Rsim+1) = gaussian_kernel(i+Rsim+1, j+Rsim+1) / kernel_sum;
        end
    end
end

