load('recon_T1_synthetic_normal_1mm_L8_r2.mat') % wczytanie pliku
m=matfile('recon_T1_synthetic_normal_1mm_L8_r2.mat');
%image=m.SENSE_LSE;
image=m.SENSE_LSE;
%image =('dataset_T1.mat')
N = input('Podaj rozmiar rozszerzenia N(x)');
M = input('Podaj rozmiar rozszerzenia M(y)');
Image1=unsample(image,N,M);
figure(1)
ii=1;
down =0;
while(1)
%imagesc(image);colormap(gray);
Image2=filtr_bil(Image1,2,100);
d(ii)=mean(abs(Image1(:)-Image2(:)));
if(d(ii)<0.4)
    break;
end
ii=ii+1;
down =1;


end

figure(2)
imagesc(Image1);colormap(gray);
figure(3)
imagesc(Image2);colormap(gray);

