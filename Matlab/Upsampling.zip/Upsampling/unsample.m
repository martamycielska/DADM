function [roz] = unsample(image,N,M)
%Image -obraz wej�ciow
%N- rozszerzenie 
%M - rozszerzenie

lf=[N, M]; % wektor rozszerzenia
s=size(image).*lf; %rozmiar obrazu po rozszerzeniu
step=(1+lf)/2; % krok 
% int lf =(N,M)

[x, y]=ndgrid(step(1):lf(1):1-step(1)+s(1), step(2):lf(2):1-step(2)+s(2));
[xi, yi]=ndgrid(1:s(1), 1:s(2));
 image_un = interpn(x,y,image,xi,yi,'spline'); 

% deal with extreme slices
 for i=1:floor(lf(1)/2)
   image_un(i,:) = image_un(floor(lf(1)/2)+1,:);
 end
for i=1:floor(lf(2)/2)
  image_un(:,i) = image_un(:,floor(lf(2)/2)+1);
end
 
 for i=1:floor(lf(1)/2)
   image_un(s(1)-i+1,:) = image_un(s(1)-floor(lf(1)/2),:);
 end
 for i=1:floor(lf(2)/2)
   image_un(:,s(2)-i+1) = image_un(:,s(2)-floor(lf(2)/2));  
 end

% mean correction
 for i=1:lf(1):s(1)
 for j=1:lf(2):s(2)
   
     tmp=image_un(i:i+lf(1)-1,j:j+lf(2)-1);  
     off=image((i+lf(1)-1)/lf(1),(j+lf(2)-1)/lf(2))-mean(tmp(:));
     roz(i:i+lf(1)-1,j:j+lf(2)-1)=image_un(i:i+lf(1)-1,j:j+lf(2)-1)+off;
 end
 end


end
