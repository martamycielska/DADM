function [im_filtred] = filtr_bil(image_roz,w,h)

dim = size(image_roz);
B = zeros(dim);
for i = 1:dim(1)
   for j = 1:dim(2)
         iMin = max(i-w,1);
         iMax = min(i+w,dim(1));
         jMin = max(j-w,1);
         jMax = min(j+w,dim(2));
         I = image_roz(iMin:iMax,jMin:jMax); % okno warto�� piksela okna
         H = exp(-(I-image_roz(i,j)).^2/(h^2)); % intesywno��
        for k=iMin:iMax
             for m=jMin:jMax
                   O = exp(-(sqrt((k-i)^2+(m-j)^2))/h^2); % odleg�o��
             end
        end
        
         F =H.*O;
         im_filtred(i,j) = sum(F(:).*I(:))/sum(F(:)); % suma wag razy intesywno�� punktu przez sume wag
               
   end
  
   
end

end