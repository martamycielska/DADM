
%user input parameters
z_in = 90;
rot_x = 30;
rot_y = 0;

mri_data = zeros(500, 500, 500);
mri_data_load = load('dataset_T1.mat');
mri_data_load = mri_data_load.SENSE_LSE;

image_base = mri_data_load(:,:,90);
figure;
imshow(image_base, []); 
%add borders
offset = 150;
size_x = size(mri_data_load,1);
size_y = size(mri_data_load,2);
size_z = size(mri_data_load,3);
mri_data(150:(150+size_x-1), 150:(150+size_y-1), 150:(150+size_z-1))= mri_data_load;

point = [0,0,z_in]+[offset, offset, offset]+[size_x/2, size_y/2, 0];
v1 = [1,0,0];
v2 = [0,1,0];
p = [0,0,0];

%x rotation 
Mx = rotx(rot_x);
v1 = Mx*v1(:);
v2 = Mx*v2(:);
v1 = transpose(v1);
v2 = transpose(v2);

%y rotation 
Mx = roty(rot_y)
v1 = Mx*v1(:);
v2 = Mx*v2(:);
v1 = transpose(v1);
v2 = transpose(v2);

v1 = abs(v1);
v2 = abs(v2);
%%interpolation
localMean = imboxfilt3(mri_data,[3 3 3]);


%find plane's points having equation: p = s*v1 + t*v2 + c
for t=-127:127
    for s =-127:127
        p = t*v1 + s*v2 + point;
        p = round(p);
        plane_x(s+128,t+128) = p(1);
        plane_y(s+128,t+128) = p(2);
        plane_z(128-s,128-t) = p(3);
        
        image_out(s+128,t+128) = localMean(p(1), p(2), p(3));
    end
end

%visualisation
figure
plot3(plane_x, plane_y, plane_z,'.k','MarkerSize',1);
    xlabel('x');
    ylabel('y');
    zlabel('z');
    grid on;
    xlim([0, size_x]); ylim([0,size_y]); zlim([0, size_z]);
    xlim([0, 600]); ylim([0,600]); zlim([0, 400]);
figure;
imshow(image_out, []); 


