clear all
close all
%wczytanie danych
load 'T1_synthetic_normal_1mm_L8_r2.mat'
%parametry
ReductionFactor = r;
CoilsNo= L;
image_length = size(raw_data,2); 

%utworzenie wektora kolejnych obraz�w
for i=1:length(raw_data(1,1,:))
    I_raw{i} = raw_data(:,:,i);
    %figure,imshow(I_raw{i});
end

%utworzenie wektora kolejnych map czu�o�ci
for i=1:length(raw_data(1,1,:))
    S{i} = mat2gray(abs(sensitivity_maps(:,:,i)));
    %figure,imshow(S{i});
end

%Transformata Fouriera 
for i=1:length(I_raw)
    AliasedImage{i} = mat2gray(abs(ifftn(I_raw{i})));
    %figure,imshow(AliasedImage{i});
end

%REKONSTRUKCJA OBRAZU
Image = zeros(image_length);
%ReductionFactor-wsp�lczynnik redukcji
rec_step=image_length/ReductionFactor;  
Sx = zeros(CoilsNo,ReductionFactor);
Dr = zeros(ReductionFactor); 
for x=1:size(I_raw{1},1)
    for y=1:size(I_raw{1},2) 

        for j=1:CoilsNo %liczba cewek
            Sx(j,:) = [S{j}(x,y),S{j}(x+rec_step,y)];
        end
    
        for k=1:CoilsNo
            Ds(k) = AliasedImage{k}(x,y);
        end
        Ds = Ds(:); %obr�cenie macierzy
        Dr = (inv(Sx'*Sx)*Sx')*Ds; 
        
        %zrekonstruowany obraz
        Image(x,y) = Dr(1);
        Image(x+rec_step,y) = Dr(2);
        
    end
end

figure, imshow(Image)
%zapis do pliku
save Image;


