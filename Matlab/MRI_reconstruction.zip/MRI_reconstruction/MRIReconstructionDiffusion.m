close all
clear all
%wczytanie danych
load 'diffusion_synthetic_normal_L8_r2_gr15_b1200.mat';
I1 = raw_data(:,:,1,1);
grad=length(gradients(:,1));
all_raw_data=raw_data;
reconstructed_images=zeros(256,256,grad);

for c=1:grad
    
raw_data=all_raw_data(:,:,c,:);
%parametry
ReductionFactor = r;
CoilsNo= L;
image_length = size(raw_data,2); 

%utworzenie wektora kolejnych obraz�w
for i=1:length(raw_data(1,1,:))
    I_raw{i} = raw_data(:,:,i);
    %figure,imshow(I_raw{i});
end

%utworzenie wektora kolejnych map czu�o�ci
for i=1:length(raw_data(1,1,:))
    S{i} =(abs(sensitivity_maps(:,:,i)));
end

%Transformata Fouriera 
for i=1:length(I_raw)
    AliasedImage{i} =((abs(ifftn(I_raw{i}))));
   
end


%REKONSTRUKCJA OBRAZU
Image = zeros(image_length);
rec_step=image_length/ReductionFactor; 
Sx = zeros(CoilsNo,ReductionFactor);
Dr = zeros(ReductionFactor); 
for x=1:size(I_raw{1},1)
    for y=1:size(I_raw{1},2) 

        for j=1:CoilsNo
            Sx(j,:) = [S{j}(x,y),S{j}(x+rec_step,y)];
        end
    
        for k=1:CoilsNo
            Ds(k) = AliasedImage{k}(x,y);
        end
        Ds = Ds(:); %obr�cenie macierzy
        Dr = (inv(Sx'*Sx)*Sx')*Ds;
        
        %zrekonstruowany obraz
        Image(x,y) = Dr(1);
        Image(x+rec_step,y) = Dr(2);
        
          end
end
figure 
imshow(mat2gray(Image));

      %REGULARYZACJA
lambda=0.02;%parametr regularyzacji
A=[1,0;0,1];%macierz jednostkowa
Image1 = zeros(image_length);
D = medfilt2(Image,[4 4]); %filtracja medianowa

for x=1:size(I_raw{1},1)
    for y=1:size(I_raw{1},2) 

        for j=1:CoilsNo
            Sx(j,:) = [S{j}(x,y),S{j}(x+step,y)];
        end

        for k=1:CoilsNo
            Ds(k) = AliasedImage{k}(x,y);
        end
        Ds = Ds(:); %obr�cenie macierzy
        Dr = [D(x,y);D(x+step,y)]; %piksele poprzedniego obrazu
        Dr1 =Dr+(inv((Sx'*Sx)+((lambda^2)*A'*A))*Sx'*(Ds-(Sx*Dr)));
        Image1(x,y) = Dr1(1);
        Image1(x+step,y) = Dr1(2);
    end
end
figure 
imshow(mat2gray(Image1));
reconstructed_images(:,:,c)=Image;

end




