NrB0 = 7; 
NrOfDirections = 48; 
bvecs(:,:) = dwi.bvecs;
bvals(:,:) = dwi.bvals;

% B-matrix
b = [bvals(:).*bvecs(:,1).^2 2*bvals(:).*bvecs(:,1).*bvecs(:,2) 2*bvals(:).*bvecs(:,1).*bvecs(:,3)...
        bvals(:).*bvecs(:,2).^2 2*bvals(:).*bvecs(:,2).*bvecs(:,3) bvals(:).*bvecs(:,3).^2];
B = [ones(NrB0+NrOfDirections,1) -b];

% Estimate diffusion tensor
order = [1 2 3 5 6 9];

for k=1:76;
    for i=1:116;
        for j=1:116;        

                dwi_data = double(squeeze(dwi.data(i,j,k,:)));
                dwi_data(dwi_data==0)=1;
                covar = diag(dwi_data.^2);
                logarytmy = log(dwi_data);
                X = inv(B'*covar*B) *(B'*covar) *log(dwi_data);
                dti_data.tensor(k).matrix(i,j,order) = single(X(2:end));

        end
    end

end
for i=1:76
    dti_data.tensor(i).eigenvalues(:,:,1) = dti_data.tensor(i).matrix(:,:,1);
    dti_data.tensor(i).eigenvalues(:,:,2) = dti_data.tensor(i).matrix(:,:,5);
    dti_data.tensor(i).eigenvalues(:,:,3) = dti_data.tensor(i).matrix(:,:,9);
end

%%  diffusion anisotropy indices 
for i = 1:76
    lambda_1 = dti_data.tensor(i).matrix(:,:,1);
    lambda_2 = dti_data.tensor(i).matrix(:,:,5);
    lambda_3 = dti_data.tensor(i).matrix(:,:,9);
    
    MD{i} = (lambda_1+lambda_2+lambda_3)/3;
    figure, imshow(dwi.data(:,:,i,1).*MD{i});
    RA{i} = sqrt(((lambda_1-MD{i}).^2)...
        +((lambda_2-MD{i}).^2)+((lambda_3-MD{i}).^2))./sqrt(3*MD{i});
    RA{i}(isnan(RA{i}))=0;
    RA{i} = real(RA{i});
  
    FA{i} = sqrt(3*(((lambda_1-MD{i})^2)+((lambda_2-MD{i})^2)...
        +((lambda_3-MD{i})^2))./sqrt(2*((lambda_1^2)...
        +(lambda_2^2)+(lambda_3^2))));
    FA{i}(isnan(FA{i}))=0;
    FA{i} = real(FA{i});
    RED = min(30+1.5+abs(dwi.data(:,:,i,1).*FA{i}.*lambda_1*255),255);
    GREEN = min(30+1.5+abs(dwi.data(:,:,i,2).*FA{i}.*lambda_2*255),255);
    BLUE = min(30+1.5+abs(dwi.data(:,:,i,3).*FA{i}.*lambda_3*255),255);
    figure, imshow(dwi.data(:,:,i,:));
    
    VR{i} = (lambda_1*lambda_2*lambda_3)./(MD{i})^3;      
    VR{i}(isnan(VR{i}))=0;
    VR{i} = real(VR{i});
     

end
